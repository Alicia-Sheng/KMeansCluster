package pa06;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * 
 * @author presenting
 *
 */
public class KMeans {
	Cluster originalData;
	ArrayList<Cluster> clusters;
	
	public KMeans(ArrayList<Cluster> originalData,int k) {
		
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		Scanner file=new Scanner(new File("Test.txt"));
		ArrayList<Sample> allSamples=new ArrayList<Sample>();
		
		while (file.hasNextLine()){
			ArrayList<Double> coordinates=new ArrayList<Double>();
			coordinates.add(file.nextDouble());
			Sample row=new Sample(coordinates);
			allSamples.add(row);
		}

		Cluster orignalData=new Cluster(allSamples);
		System.out.println(orignalData.printCluster());
	}

	
}
